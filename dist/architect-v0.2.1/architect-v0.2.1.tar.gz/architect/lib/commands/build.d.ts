import Listr from 'listr';
import Command from '../base';
import ServiceDependency from '../common/service-dependency';
export default class Build extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        recursive: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        _local: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: {
        name: string;
        description: string;
    }[];
    run(): Promise<void>;
    tasks(): Promise<Listr.ListrTask[]>;
    buildImage(service: ServiceDependency): Promise<void>;
}
