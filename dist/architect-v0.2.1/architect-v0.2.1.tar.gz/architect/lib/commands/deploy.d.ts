import { flags } from '@oclif/command';
import Command from '../base';
import { EnvironmentMetadata } from '../common/environment-metadata';
import ServiceDependency from '../common/service-dependency';
export default class Deploy extends Command {
    static description: string;
    static args: {
        name: string;
        description: string;
    }[];
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        environment: flags.IOptionFlag<string | undefined>;
        deployment_id: flags.IOptionFlag<string | undefined>;
        local: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        config_file: flags.IOptionFlag<string | undefined>;
    };
    run(): Promise<void>;
    validate_parameters(root_service: ServiceDependency, config_json: any): void;
    read_parameter(value: string): Promise<string>;
    parse_config(): Promise<EnvironmentMetadata>;
    run_local(): Promise<void>;
    run_external(): Promise<void>;
    deploy(deployment_id: string): Promise<void>;
    promptOptions(): Promise<{
        service_name: any;
        service_version: any;
        environment: string | undefined;
        deployment_id: string | undefined;
    }>;
}
