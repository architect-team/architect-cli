export interface StringValidator {
    test(str: string): boolean;
}
export declare class SemvarValidator implements StringValidator {
    test(str: string): boolean;
}
export declare const EnvironmentNameValidator: RegExp;
export declare const ServiceNameValidator: RegExp;
export declare const EnvNameValidator: RegExp;
