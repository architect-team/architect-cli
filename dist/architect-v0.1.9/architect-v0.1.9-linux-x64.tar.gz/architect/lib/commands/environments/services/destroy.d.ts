import { flags } from '@oclif/command';
import Command from '../../../base';
export default class DestroyService extends Command {
    static description: string;
    static aliases: string[];
    static args: {
        name: string;
        description: string;
        required: boolean;
    }[];
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        environment: flags.IOptionFlag<string | undefined>;
        deployment_id: flags.IOptionFlag<string | undefined>;
    };
    run(): Promise<void>;
    deploy(deployment_id: string): Promise<void>;
    promptOptions(): Promise<any>;
}
