import { AppConfig } from '../app-config';
import ServiceConfig from './service-config';
export default abstract class ServiceDependency {
    static create(app_config: AppConfig, service_path: string, _root?: boolean): ServiceDependency;
    private static readonly _cache;
    readonly app_config: AppConfig;
    readonly service_path: string;
    readonly root: boolean;
    local: boolean;
    protected _config: ServiceConfig;
    protected _api_definitions: {
        [key: string]: string;
    };
    protected _loaded: boolean;
    constructor(app_config: AppConfig, service_path: string, _root: boolean);
    readonly config: ServiceConfig;
    readonly api_definitions: {
        [key: string]: string;
    };
    readonly dependencies: ServiceDependency[];
    readonly all_dependencies: ServiceDependency[];
    readonly local_dependencies: ServiceDependency[];
    override_configs(overrides: any): void;
    load(): Promise<void>;
    abstract _load(): Promise<void>;
    abstract readonly tag: string;
}
