import Listr from 'listr';
import Command from '../base';
import ServiceDependency from '../common/service-dependency';
export default class Push extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: {
        name: string;
        description: string;
    }[];
    run(): Promise<void>;
    tasks(): Promise<Listr.ListrTask[]>;
    pushImage(service: ServiceDependency): Promise<void>;
}
