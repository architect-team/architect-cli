declare enum SUPPORTED_LANGUAGES {
    NODE = "node",
    PYTHON = "python"
}
export default SUPPORTED_LANGUAGES;
