export declare const readIfFile: (string_or_path: string) => Promise<string>;
