declare namespace PortUtil {
    const isPortAvailable: (port: number) => Promise<boolean>;
    const getAvailablePort: () => Promise<number>;
}
export default PortUtil;
