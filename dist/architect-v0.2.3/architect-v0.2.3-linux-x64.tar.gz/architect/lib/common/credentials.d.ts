declare const _default: {
    setPassword: (service: string, account: string, password: string) => Promise<void>;
    deletePassword: (service: string) => Promise<void>;
    findCredential: (service: string) => Promise<{
        account: string;
        password: string;
    }>;
};
export default _default;
