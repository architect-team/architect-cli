import { flags } from '@oclif/command';
import Command from '../base';
export default class Init extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        description: flags.IOptionFlag<string | undefined>;
        version: flags.IOptionFlag<string | undefined>;
        keywords: flags.IOptionFlag<string | undefined>;
        author: flags.IOptionFlag<string | undefined>;
        license: flags.IOptionFlag<string | undefined>;
        output: flags.IOptionFlag<string | undefined>;
    };
    static args: {
        name: string;
        char: string;
        default: string;
        parse: (value: string) => string;
    }[];
    run(): Promise<void>;
    promptOptions(): Promise<unknown>;
}
